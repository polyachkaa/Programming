import tkinter as tk
from tkinter import filedialog
import pyzipper
import os
import time

class FolderSection(tk.Frame):
    def __init__(self, parent, result_label):
        super().__init__(parent, bg="#EAE2D6", borderwidth=4, relief="ridge")
        self.result_label = result_label

        folder_label = tk.Label(self, text="Выберите папку для архивации:", font=("Arial", 12, 'bold'), fg='MistyRose4', bg="#EAE2D6")
        folder_label.grid(row=0, column=0, padx=10, pady=5, sticky="w",)

        self.selected_folder = tk.StringVar()
        folder_entry = tk.Entry(self, textvariable=self.selected_folder, font=("Arial", 12))
        folder_entry.grid(row=0, column=1, padx=10, pady=5, sticky="we")

        browse_folder_button = tk.Button(self, text="Обзор", command=self.browse_folder, font=("Arial", 12, 'bold'), fg='MistyRose4')
        browse_folder_button.grid(row=0, column=2, padx=10, pady=5, sticky="e")

        archive_name_label = tk.Label(self, text="Имя архива (без расширения):", font=("Arial", 12, 'bold'), fg='MistyRose4', bg="#EAE2D6")
        archive_name_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")

        self.archive_name_entry = tk.Entry(self, font=("Arial", 12))
        self.archive_name_entry.grid(row=1, column=1, padx=10, pady=5, sticky="we")

        self.encrypt_checkbox_var = tk.IntVar()
        encrypt_checkbox = tk.Checkbutton(self, text="Зашифровать архив", variable=self.encrypt_checkbox_var, font=("Arial", 12, 'bold'), fg='MistyRose4', bg="#EAE2D6")
        encrypt_checkbox.grid(row=2, column=1, padx=10, pady=5, sticky="w")

        password_label = tk.Label(self, text="Пароль для архива:", font=("Arial", 12, 'bold'), fg='MistyRose4', bg="#EAE2D6")
        password_label.grid(row=3, column=0, padx=10, pady=5, sticky="w")

        self.password_entry = tk.Entry(self, show='*', font=("Arial", 12))
        self.password_entry.grid(row=3, column=1, padx=10, pady=5, sticky="we")

        create_button = tk.Button(self, text="Создать архив", command=self.create_archive, font=("Arial", 12,'bold'), fg='MistyRose4')
        create_button.grid(row=4, column=1, padx=10, pady=10, sticky="e")

    def create_menu(self):
        menubar = tk.Menu(self)
        self.config(menu=menubar)

        # Меню "Файл"
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Файл", menu=file_menu)
        file_menu.add_command(label="Создать папку", command=self.create_folder)
        file_menu.add_command(label="Создать файл", command=self.create_file)

        # Меню "Помощь"
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Помощь", menu=help_menu)
        help_menu.add_command(label="О программе", command=self.show_about_dialog)

    def browse_folder(self):
        folder_path = filedialog.askdirectory()
        self.selected_folder.set(folder_path)

    def create_archive(self):
        folder_path = self.selected_folder.get()
        archive_name = self.archive_name_entry.get()
        encrypt_archive = self.encrypt_checkbox_var.get()
        password = self.password_entry.get()

        if not archive_name or not folder_path:
            self.result_label.config(text="Введите имя архива и выберите папку для архивации", fg='white')
            return

        if not archive_name.endswith(".zip"):
            archive_name += ".zip"

        downloads_dir = os.path.expanduser("~/Downloads")

        if not os.path.exists(downloads_dir):
            os.makedirs(downloads_dir)

        archive_path = os.path.join(downloads_dir, archive_name)

        try:
            if encrypt_archive:
                with pyzipper.AESZipFile(archive_path, 'w', compression=pyzipper.ZIP_LZMA, encryption=pyzipper.WZ_AES) as zipf:
                    zipf.setpassword(password.encode())
                    for root, dirs, files in os.walk(folder_path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, folder_path)
                            zipf.write(file_path, arcname=arcname)
            else:
                with pyzipper.ZipFile(archive_path, 'w', compression=pyzipper.ZIP_LZMA) as zipf:
                    for root, dirs, files in os.walk(folder_path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, folder_path)
                            zipf.write(file_path, arcname=arcname)

            self.result_label.config(text=f"Сжатая zip-папка {archive_name} успешно создана и сохранена в <Загрузки>", fg='white')
        except Exception as e:
            self.result_label.config(text=f"Ошибка: {str(e)}")

class ExtractSection(tk.Frame):
    def __init__(self, parent, result_label):
        super().__init__(parent, bg="#EAE2D6", borderwidth=4, relief="ridge")
        self.result_label = result_label

        extract_label = tk.Label(self, text="Выберите архив для извлечения:", font=("Arial", 12, 'bold'), fg='MistyRose4', bg="#EAE2D6")
        extract_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")

        self.selected_archive = tk.StringVar()
        archive_entry = tk.Entry(self, textvariable=self.selected_archive, font=("Arial", 12))
        archive_entry.grid(row=0, column=1, padx=10, pady=5, sticky="we")

        self.extract_encrypt_checkbox_var = tk.IntVar()
        extract_encrypt_checkbox = tk.Checkbutton(self, text="Архив зашифрован", variable=self.extract_encrypt_checkbox_var, font=("Arial", 12, 'bold'), fg='MistyRose4', bg="#EAE2D6")
        extract_encrypt_checkbox.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        password_extract_label = tk.Label(self, text="Пароль для архива:", font=("Arial", 12, 'bold'), fg='MistyRose4', bg="#EAE2D6")
        password_extract_label.grid(row=2, column=0, padx=10, pady=5, sticky="w")

        self.password_extract_entry = tk.Entry(self, show='*', font=("Arial", 12))
        self.password_extract_entry.grid(row=2, column=1, padx=10, pady=5, sticky="we")

        browse_archive_button = tk.Button(self, text="Обзор", command=self.browse_archive, font=("Arial", 12, 'bold'), fg='MistyRose4')
        browse_archive_button.grid(row=0, column=2, padx=10, pady=5, sticky="e")

        extract_button = tk.Button(self, text="Извлечь архив", command=self.extract_archive, font=("Arial", 12, 'bold'), fg='MistyRose4')
        extract_button.grid(row=3, column=1, padx=10, pady=10, sticky="e")

    def browse_archive(self):
        archive_path = filedialog.askopenfilename(filetypes=[("ZIP Files", "*.zip")])
        self.selected_archive.set(archive_path)
        self.selected_archive.set()

    def extract_archive(self):
        archive_path = self.selected_archive.get()
        extract_encrypt = self.extract_encrypt_checkbox_var.get()
        password = self.password_extract_entry.get()

        if not archive_path:
            self.result_label.config(text="Выберите архив для извлечения")
            return

        extract_dir = os.path.expanduser("~/Downloads")

        try:
            if extract_encrypt:
                with pyzipper.AESZipFile(archive_path, 'r', encryption=pyzipper.WZ_AES) as zipf:
                    zipf.setpassword(password.encode())
                    zipf.extractall(extract_dir)
            else:
                with pyzipper.ZipFile(archive_path, 'r') as zipf:
                    zipf.extractall(extract_dir)

            self.result_label.config(text=f"Архив {os.path.basename(archive_path)} успешно извлечен в Загрузки")
        except Exception as e:
            self.result_label.config(text=f"Ошибка при извлечении архива: {str(e)}")

class ArchiverApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Архиватор")
        self.configure(bg="#A49393")

        self.geometry("1300x600")
        self.minsize(1300, 600)
        self.title_font = ("Arial", 18)
        self.iconbitmap('C:\\Users\\student\\PycharmProjects\\pythonProject30\\Aniket-Suvarna-Box-Regular-Bx-box.ico')

        self.create_widgets()
        self.create_menu()

    def create_widgets(self):
        frame = tk.Frame(self, bg="#A49393")
        frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.result_label = tk.Label(frame, text="", font=("Arial", 12), bg="#A49393")
        self.result_label.grid(row=5, column=0, columnspan=3, padx=10, pady=10, sticky="w")

        folder_section = FolderSection(frame, self.result_label)
        folder_section.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        extract_section = ExtractSection(frame, self.result_label)
        extract_section.grid(row=0, column=1, padx=10, pady=10, sticky="w")

        # Добавьте окно проводника в основное окно
        self.file_explorer = FileExplorer(frame)
        self.file_explorer.grid(row=1, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")

        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)
        frame.rowconfigure(1, weight=1)

    def create_menu(self):
        menubar = tk.Menu(self)
        self.config(menu=menubar)

        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Помощь", menu=help_menu)
        help_menu.add_command(label="О программе", command=self.show_about_dialog)

    def show_about_dialog(self):
        about_text = "Выполнено студентами КМПО РАНХиГС группы 32ИС-21:\n" \
                     "Кубадиевым Ильясом\n" \
                     "Головачевой Полиной"
        about_dialog = tk.Toplevel(self)
        about_dialog.title("О программе")
        about_label = tk.Label(about_dialog, text=about_text, font=("Arial", 12), padx=20, pady=20)
        about_label.pack()

class FileExplorer(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="#EAE2D6", borderwidth=4, relief="ridge")
        self.bind("<ButtonRelease-1>", self.on_file_click)
        self.parent = parent
        self.parent.bind('<Configure>', self.update_listbox_size)  # Обновление размера Listbox

        self.file_listbox = tk.Listbox(self, selectmode=tk.SINGLE, font=("Arial", 12))
        self.file_listbox.pack(fill=tk.BOTH, expand=True)

        self.scrollbar = tk.Scrollbar(self, orient="vertical", command=self.file_listbox.yview)
        self.scrollbar.pack(side="right", fill="y")
        self.file_listbox.config(yscrollcommand=self.scrollbar.set)

        default_path = os.path.expanduser("~/Downloads")
        self.load_files(default_path)

        self.file_listbox.bind('<ButtonRelease-1>', self.on_file_click)

    def update_listbox_size(self, event):
        # Обновление размера Listbox при изменении размера окна
        self.file_listbox.config(width=event.width // 12, height=event.height // 25)

    def load_files(self, path):
        self.file_listbox.delete(0, tk.END)
        try:
            items = os.listdir(path)
            folders = [item for item in items if os.path.isdir(os.path.join(path, item))]
            max_folder_name_length = max(len(folder) for folder in folders)
            for folder in folders:
                folder_path = os.path.join(path, folder)
                modification_time = os.path.getmtime(folder_path)
                modification_time_str = time.strftime('%Y-%m-%d', time.localtime(modification_time))
                folder_text = folder.ljust(max_folder_name_length)
                item_text = f"{folder_text} {modification_time_str}"
                self.file_listbox.insert(tk.END, item_text)
        except OSError as e:
            print(f"Ошибка при загрузке файлов: {str(e)}")

    def on_file_click(self, event):
        selected_file = self.file_listbox.get(self.file_listbox.curselection())
        print(selected_file)

if __name__ == "__main__":
    app = ArchiverApp()
    app.mainloop()
