from PyQt5.QtWidgets import QDialog, QGridLayout, QPushButton, QGraphicsView, QGraphicsScene, QGraphicsEllipseItem, QGraphicsRectItem, QGraphicsSimpleTextItem
from PyQt5.QtGui import QPen, QColor, QFont
from PyQt5.QtCore import Qt, QRectF
from collections import Counter
import sqlite3
from PyQt5 import uic

class Diagram(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('diagram.ui', self)
        self.setFixedSize(771, 630)
        self.setWindowTitle("Диаграмма")

        # Создание макета для диалога
        layout = QGridLayout(self)
        self.graphics_view = QGraphicsView(self)
        layout.addWidget(self.graphics_view, 0, 0, 1, 2)

        # Добавление кнопки "Назад"
        back_button = QPushButton("Назад", self)
        back_button.clicked.connect(self.close)  # Подключение кнопки к функции закрытия

        # Установка размера и цвета кнопки
        back_button.setFixedSize(120, 50)
        back_button.setStyleSheet(
            "QPushButton {"
            "   background-color: red;"
            "   color: white;"
            "   font-family: Myanmar Text;"
            "   font-size: 16px;"
            "   font-weight: bold;"
            "   border-radius: 10px;"
            "   border: 2px solid #00007f;"
            "}"
            "QPushButton:hover {"
            "   background-color: #f30000;"
            "}"
        )

        layout.addWidget(back_button, 1, 0, 1, 2)

        self.db_connection = sqlite3.connect('chemists.db')
        self.cursor = self.db_connection.cursor()
        self.fetch_data_and_draw_diagram()

    def fetch_data_and_draw_diagram(self):
        # Получение данных из базы данных
        self.cursor.execute('SELECT форма_выпуска_товара FROM Продажи')
        product_forms = [row[0] for row in self.cursor.fetchall()]

        # Подсчет встречаемости каждой формы товара
        form_counts = Counter(product_forms)

        # Расчет процентов
        total_sales = len(product_forms)
        percentages = {form: count / total_sales * 100 for form, count in form_counts.items()}

        # Нарисовать диаграмму
        self.draw_pie_chart(percentages)

    def draw_pie_chart(self, percentages):
        scene = QGraphicsScene(self)
        chart_size = min(self.width(), self.height()) - 120
        chart_rect = QRectF(10, 10, chart_size, chart_size)

        total_percentage = sum(percentages.values())

        start_angle = 0
        legend_labels = []

        # Определение пользовательской цветовой палитры
        color_palette = [QColor("hotpink"), QColor("plum"), QColor("orchid"), QColor("purple")]

        for i, (form, percentage) in enumerate(percentages.items()):
            span_angle = int(percentage / total_percentage * 360 * 16)  # Преобразование в целочисленный угол

            pie_slice = QGraphicsEllipseItem(chart_rect)

            # Установка свойств пера для увеличения толщины границы
            pen = QPen()
            pen.setWidth(2)
            pie_slice.setPen(pen)

            # Установка начального и угла развертывания для сегмента
            pie_slice.setStartAngle(int(start_angle * 16))
            pie_slice.setSpanAngle(span_angle)

            # Использование пользовательской цветовой палитры
            color = color_palette[i % len(color_palette)]
            pie_slice.setBrush(color)

            scene.addItem(pie_slice)

            # Добавление подписи в легенду
            legend_labels.append((form, percentage, color))
            start_angle += span_angle / 16

        # Настройка графического представления
        self.graphics_view.setScene(scene)
        self.graphics_view.setAlignment(Qt.AlignCenter)
        self.graphics_view.setViewportUpdateMode(QGraphicsView.FullViewportUpdate)

        # Добавление цветных меток рядом с графическим представлением
        label_offset = 40
        font_size = 12

        for i, (form, percentage, color) in enumerate(legend_labels):
            legend_label = QGraphicsRectItem(0, 0, label_offset, label_offset)
            legend_label.setPos(chart_size + 20, i * label_offset)
            legend_label.setBrush(color)
            scene.addItem(legend_label)

            # Добавление текстовых меток
            text_item = QGraphicsSimpleTextItem(f"{form}: {percentage:.2f}%", legend_label)
            text_item.setPos(label_offset + 10, 5)
            font = QFont()
            font.setPointSize(font_size)
            text_item.setFont(font)
            text_item.setBrush(QColor("black"))

    def closeEvent(self, event):
        self.db_connection.close()  # Закрыть соединение с базой данных перед закрытием диалога
        event.accept()

