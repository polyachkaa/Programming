from PyQt5 import uic
from PyQt5.QtWidgets import QDialog, QMessageBox
import sqlite3

class Second(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('second.ui', self)
        self.setFixedSize(801, 651)
        self.Back_Button.clicked.connect(self.go_back)
        self.Registration_Client.clicked.connect(self.register_client)

    def go_back(self):
        # Скрыть текущий диалог вместо его отклонения
        self.hide()

    def register_client(self):
        # Получить данные из полей ввода
        login = self.lineEdit_login.text()
        password = self.lineEdit_password.text()
        name = self.Client_Name.text()
        last_name = self.Client_LastName.text()
        otch = self.Client_Otch.text()
        phone_num = self.Client_PhoneNum.text()
        city = self.Client_City.text()
        address = self.Client_Address.text()

        # Проверить введенные данные
        if not login or not password or not name or not last_name or not phone_num or not city or not address:
            QMessageBox.warning(self, 'Предупреждение', 'Пожалуйста, заполните все обязательные поля.')
            return

        try:
            # Подключиться к базе данных
            db_connection = sqlite3.connect('chemists.db')
            cursor = db_connection.cursor()

            # Выполнить SQL-запрос для вставки данных в таблицу "Клиенты"
            cursor.execute('''
                        INSERT INTO Клиенты (логин, пароль, имя, фамилия, отчество, номер_телефона, город, адрес)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (login, password, name, last_name, otch, phone_num, city, address))

            # Применить изменения к базе данных
            db_connection.commit()

            # Отобразить сообщение об успешной регистрации
            QMessageBox.information(self, 'Успех', 'Регистрация успешна!')

            # Очистить поля ввода
            self.clear_input_fields()

        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось зарегистрировать клиента: {str(e)}')

    def clear_input_fields(self):
        # Очистить все поля ввода
        self.lineEdit_login.clear()
        self.lineEdit_password.clear()
        self.Client_Name.clear()
        self.Client_LastName.clear()
        self.Client_Otch.clear()
        self.Client_PhoneNum.clear()
        self.Client_City.clear()
        self.Client_Address.clear()