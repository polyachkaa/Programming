from PyQt5.QtWidgets import QDialog, QMessageBox
from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QStandardItemModel, QStandardItem
import sqlite3
from PyQt5 import uic

class user(QDialog):
    user_logged_in = pyqtSignal(tuple)

    def __init__(self, parent=None, third_dialog=None, cursor=None, db_connection=None):
        super().__init__(parent)
        uic.loadUi('user.ui', self)
        self.setFixedSize(1009, 773)
        self.third_dialog = third_dialog
        self.cursor = cursor
        self.db_connection = db_connection
        # Создание модели
        self.model = QStandardItemModel(self)
        self.Buy_Button.clicked.connect(self.make_sale)
        self.Back_ButtonUser.clicked.connect(self.go_back)

        # Привязка модели к QTableView
        self.Products_List.setModel(self.model)

        try:
            # Подключение к базе данных
            self.connection = sqlite3.connect('chemists.db')
            self.cursor = self.connection.cursor()

            # Заполнение comboBox аптеками из базы данных
            self.populate_chemist_list()

            # Связываем событие изменения аптеки с функцией обновления списка продуктов
            self.Chemist_List.currentIndexChanged.connect(self.update_products_list)

            # Закрытие соединения с базой данных при закрытии окна
            self.finished.connect(self.connection.close)
        except Exception as e:
            print(f"Error during initialization: {e}")

    def go_back(self):
        # Скрыть текущий диалог вместо его отклонения
        self.hide()

    def populate_chemist_list(self):
        try:
            # Выполнение запроса к базе данных для получения списка аптек
            self.cursor.execute("SELECT название FROM Аптеки")
            pharmacies = self.cursor.fetchall()

            # Заполнение comboBox аптеками
            for pharmacy in pharmacies:
                self.Chemist_List.addItem(pharmacy[0])
        except Exception as e:
            print(f"Error populating chemist list: {e}")

    def update_products_list(self):
        try:
            # Очистка модели перед обновлением
            self.model.clear()

            # Получение выбранной аптеки
            selected_pharmacy = self.Chemist_List.currentText()

            # Выполнение запроса к базе данных для получения списка продуктов в выбранной аптеке
            self.cursor.execute("""
                   SELECT Товары.название, Товары.цена, Товары.форма_выпуска
                   FROM Товары
                   INNER JOIN Аптеки ON Товары.идентификатор_аптеки = Аптеки.идентификатор_аптеки
                   WHERE Аптеки.название = ?
               """, (selected_pharmacy,))
            products = self.cursor.fetchall()

            # Заполнение модели продуктами
            for row, product in enumerate(products):
                item_name = QStandardItem(product[0])
                item_price = QStandardItem(str(product[1]))
                item_form = QStandardItem(product[2])

                # Добавление элементов в модель
                self.model.setItem(row, 0, item_name)
                self.model.setItem(row, 1, item_price)
                self.model.setItem(row, 2, item_form)

        except Exception as e:
            print(f"Error updating products list: {e}")

    def make_sale(self):
        try:
            # Получение данных о продаже
            selected_pharmacy = self.Chemist_List.currentText()
            selected_item = self.model.item(self.Products_List.currentIndex().row(), 0).text()
            selected_price = float(self.model.item(self.Products_List.currentIndex().row(), 1).text())
            selected_form = self.model.item(self.Products_List.currentIndex().row(), 2).text()

            # Получение данных о текущем пользователе
            login_line_edit = getattr(self.third_dialog, "lineEdit2_login", None)
            password_line_edit = getattr(self.third_dialog, "lineEdit2_password", None)

            if login_line_edit is not None and password_line_edit is not None:
                login = login_line_edit.text()
                password = password_line_edit.text()

                # Поиск данных о пользователе в таблице "Клиенты"
                self.third_dialog.cursor.execute('SELECT имя, фамилия FROM Клиенты WHERE логин = ? AND пароль = ?',
                                                 (login, password))
                user_data = self.third_dialog.cursor.fetchone()

                if user_data:
                    user_name, user_lastname = user_data
                    # Вставка данных о продаже в таблицу "Продажи"
                    self.third_dialog.cursor.execute("""
                        INSERT INTO Продажи (имя_клиента, фамилия_клиента, название_товара, цена_товара, форма_выпуска_товара)
                        VALUES (?, ?, ?, ?, ?)
                    """, (user_name, user_lastname, selected_item, selected_price, selected_form))

                    # Подтверждение изменений в базе данных
                    self.third_dialog.db_connection.commit()

                    # Вывод успешного сообщения
                    QMessageBox.information(self, "Успех", "Продажа успешно добавлена в базу данных")
                else:
                    # Если не удалось найти пользователя, выведите сообщение об ошибке
                    QMessageBox.warning(self, "Ошибка", "Не удалось найти пользователя.")
            else:
                QMessageBox.warning(self, "Ошибка", "Не удалось получить данные о пользователе.")
        except Exception as e:
            print(f"Error making sale: {e}")

    def go_back(self):
        # Скрыть текущий диалог вместо его отклонения
        self.hide()
