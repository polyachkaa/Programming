import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QApplication
from Registration import Second
from Login import Third
from User import user

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('first.ui', self)
        self.setFixedSize(978, 744)
        self.sign_in.clicked.connect(self.on_sign_in_clicked)
        self.log_in.clicked.connect(self.on_log_in_clicked)

        # Создаем экземпляры второго и третьего диалоговых окон
        self.second_dialog = Second(self)
        self.third_dialog = Third(self)
        self.user_dialog = user(self, self.third_dialog)

    def on_sign_in_clicked(self):
        self.second_dialog.show()

    def on_log_in_clicked(self):
        self.third_dialog.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

