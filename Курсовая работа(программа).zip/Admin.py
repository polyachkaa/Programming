from PyQt5.QtWidgets import QDialog, QMessageBox
from PyQt5.QtGui import QStandardItemModel, QStandardItem
import sqlite3
from PyQt5 import uic
from Diagram import Diagram

class AdminWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('admin.ui', self)
        self.setFixedSize(1228, 878)
        self.db_connection = sqlite3.connect('chemists.db')
        self.create_tables()

        self.Button_BackAdmin.clicked.connect(self.go_back)
        self.Save_Button.clicked.connect(self.save_data)
        self.current_chemist_id = None
        self.model = QStandardItemModel(self)
        self.tableView_tables.setModel(self.model)

        self.Delete_Button.clicked.connect(self.delete_row)

        # Заполнение ID_Chemists
        self.populate_chemist_ids()
        self.ID_Chemists.currentIndexChanged.connect(self.load_chemist_data)

        self.populate_table_names()
        self.comboBox_tables.currentIndexChanged.connect(self.load_table_data)
        self.load_table_data()

        # Подключите только один метод к кнопке Save_Button
        self.Save_Button.clicked.connect(self.save_data_and_product)

        self.Diagram_Button.clicked.connect(self.on_Diagram_Button_clicked)

        self.diagram_dialog = Diagram(self)

    def go_back(self):
        # Скрыть текущий диалог вместо его отклонения
        self.hide()

    def on_Diagram_Button_clicked(self):
        self.diagram_dialog.show()

    def save_data_and_product(self):
        # Вызывайте оба метода из этого общего метод
        self.comboBox_tables.currentText() == 'Товары'
        self.save_product_data()

    def populate_chemist_ids(self):
        try:
            cursor = self.db_connection.cursor()
            cursor.execute('SELECT идентификатор_аптеки FROM Аптеки')
            chemist_ids = cursor.fetchall()
            self.ID_Chemists.addItems([str(chemist_id[0]) for chemist_id in chemist_ids])
        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось получить данные: {str(e)}')

    def load_chemist_data(self):
        # Загрузка данных для выбранной аптеки при изменении ее ID
        selected_chemist_id = self.ID_Chemists.currentText()
        self.current_chemist_id = int(selected_chemist_id)

    def delete_row(self):
        # Получить выбранный индекс строки
        selected_indexes = self.tableView_tables.selectionModel().selectedIndexes()

        if not selected_indexes:
            QMessageBox.warning(self, 'Предупреждение', 'Пожалуйста, выберите строку для удаления.')
            return

        # Получить имя столбца первичного ключа из текущей таблицы
        table_name = self.comboBox_tables.currentText()
        primary_key_column = self.get_primary_key_column(table_name)

        if not primary_key_column:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось определить первичный ключ для таблицы {table_name}.')
            return

        try:
            cursor = self.db_connection.cursor()

            # Получить значение первичного ключа для выбранной строки
            selected_primary_key = selected_indexes[0].sibling(selected_indexes[0].row(), 0).data()

            # Удалить строку с выбранным первичным ключом из текущей таблицы
            cursor.execute(f'DELETE FROM {table_name} WHERE {primary_key_column} = ?', (selected_primary_key,))
            self.db_connection.commit()

            # Перезагрузить данные таблицы после удаления
            self.load_table_data()

            QMessageBox.information(self, 'Успех',
                                    f'Строка с {primary_key_column} {selected_primary_key} успешно удалена.')
        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось удалить строку: {str(e)}')

    def get_primary_key_column(self, table_name):
        try:
            cursor = self.db_connection.cursor()
            cursor.execute(f'PRAGMA table_info({table_name})')
            columns_info = cursor.fetchall()

            for column_info in columns_info:
                column_name = column_info[1]
                if column_info[5] == 1:  # Проверить, является ли столбец первичным ключом
                    return column_name
            return None

        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось получить информацию о столбцах: {str(e)}')
            return None

    def save_data(self):
        if self.comboBox_tables.currentText() == 'Аптеки':
            chemist_name = self.Chemist_Name.text()
            chemist_address = self.Chemist_Address.text()
            chemist_city = self.Chemist_City.text()
            chemist_phone_num = self.Chemist_PhoneNum.text()

            try:
                cursor = self.db_connection.cursor()

                # Добавление данных в таблицу "Аптеки"
                cursor.execute('''
                         INSERT INTO Аптеки (название, адрес, город, телефон) VALUES (?, ?, ?, ?)
                     ''', (chemist_name, chemist_address, chemist_city, chemist_phone_num))

                self.db_connection.commit()
                self.populate_chemist_ids()  # Обновите данные в выпадающем списке ID_Chemists
                self.load_table_data()  # Обновите отображение данных в таблице

                # Очистите поля ввода после сохранения
                self.Chemist_Name.clear()
                self.Chemist_Address.clear()
                self.Chemist_City.clear()
                self.Chemist_PhoneNum.clear()

                # Выведите сообщение об успешном сохранении
                QMessageBox.information(self, 'Успех', 'Данные успешно сохранены в таблицу "Аптеки".')
            except sqlite3.Error as e:
                QMessageBox.warning(self, 'Ошибка', f'Не удалось сохранить данные: {str(e)}')

    def save_product_data(self):
        if self.comboBox_tables.currentText() == 'Товары':
            selected_pharmacy_id = self.ID_Chemists.currentText()

            try:
                cursor = self.db_connection.cursor()

                product_name = self.Product_Name.text()
                product_price_text = self.Product_Price.text()

                if not product_name or not product_price_text:
                    QMessageBox.warning(self, 'Предупреждение', 'Пожалуйста, заполните все поля для товара.')
                    return

                product_price = float(product_price_text)
                product_form = self.Product_Form.currentText()

                cursor.execute('''
                    INSERT INTO Товары (идентификатор_аптеки, название, цена, форма_выпуска) VALUES (?, ?, ?, ?)
                ''', (selected_pharmacy_id, product_name, product_price, product_form))

                self.db_connection.commit()

                # Обновите отображение данных в таблице "Товары" (не "Аптеки")
                self.load_table_data()

                QMessageBox.information(self, 'Успех', 'Данные успешно сохранены в таблицу "Товары".')
            except sqlite3.Error as e:
                QMessageBox.warning(self, 'Ошибка', f'Не удалось сохранить данные: {str(e)}')
            except ValueError as ve:
                QMessageBox.warning(self, 'Ошибка', f'Ошибка преобразования типа: {str(ve)}')

    def create_tables(self):
        cursor = self.db_connection.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS Аптеки ( 
                идентификатор_аптеки INTEGER PRIMARY KEY, 
                название TEXT NOT NULL, 
                адрес TEXT NOT NULL, 
                город TEXT NOT NULL, 
                телефон TEXT 
            ) 
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS Товары ( 
                идентификатор_товара INTEGER PRIMARY KEY, 
                идентификатор_аптеки INTEGER, 
                название TEXT NOT NULL, 
                цена REAL NOT NULL, 
                форма_выпуска TEXT NOT NULL, 
                FOREIGN KEY (идентификатор_аптеки) REFERENCES Аптеки (идентификатор_аптеки)
            ) 
        ''')

        cursor.execute('''
                CREATE TABLE IF NOT EXISTS Клиенты ( 
                    идентификатор_клиента INTEGER PRIMARY KEY, 
                    логин TEXT NOT NULL, 
                    пароль TEXT NOT NULL,
                    имя TEXT NOT NULL,
                    фамилия TEXT NOT NULL,
                    отчество TEXT NOT NULL,
                    номер_телефона VARCHAR(20),
                    адрес VARCHAR(50),
                    город VARCHAR(20)
                ) 
            ''')

        cursor.execute('''
                CREATE TABLE IF NOT EXISTS Продажи ( 
                    идентификатор_продажи INTEGER PRIMARY KEY, 
                    имя_клиента TEXT NOT NULL,
                    фамилия_клиента TEXT NOT NULL,
                    название_товара TEXT NOT NULL,
                    цена_товара REAL NOT NULL,
                    форма_выпуска_товара TEXT NOT NULL,
                    FOREIGN KEY (имя_клиента, фамилия_клиента) REFERENCES Клиенты (имя, фамилия),
                    FOREIGN KEY (название_товара, цена_товара, форма_выпуска_товара) REFERENCES Товары (название, цена, форма_выпуска)
                ) 
            ''')

        self.db_connection.commit()

    def populate_table_names(self):
        tables = self.db_connection.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
        self.comboBox_tables.addItems([table[0] for table in tables])

    def load_table_data(self):
        self.model.clear()
        table_name = self.comboBox_tables.currentText()

        cursor = self.db_connection.cursor()

        try:
            # Использование параметризованных запросов для правильной обработки имен таблиц
            cursor.execute(f'SELECT * FROM [{table_name}]')

            if table_name == "Аптеки":
                # При отображении таблицы "Аптеки" отключаем некоторые поля
                header_labels = ["идентификатор_аптеки", "название", "адрес", "город", "телефон"]
                self.Chemist_Name.setEnabled(True)
                self.Chemist_Address.setEnabled(True)
                self.Chemist_City.setEnabled(True)
                self.Chemist_PhoneNum.setEnabled(True)
            else:
                header_labels = [description[0] for description in cursor.description]
                self.Chemist_Name.setDisabled(False)
                self.Chemist_Address.setDisabled(False)
                self.Chemist_City.setDisabled(False)
                self.Chemist_PhoneNum.setDisabled(False)

            self.model.setHorizontalHeaderLabels(header_labels)

            data = cursor.fetchall()

            for row_num, row_data in enumerate(data):
                items = [QStandardItem(str(col_data)) for col_data in row_data]
                self.model.appendRow(items)

            self.tableView_tables.reset()

        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось загрузить данные: {str(e)}')

    def closeEvent(self, event):
        self.db_connection.close()  # Закрываем соединение с базой данных перед закрытием окна
        event.accept()