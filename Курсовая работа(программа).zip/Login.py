from PyQt5 import uic
from PyQt5.QtWidgets import QDialog, QMessageBox
from PyQt5.QtCore import pyqtSignal
import sqlite3
from Admin import AdminWindow
from User import user

class Third(QDialog):
    user_logged_in = pyqtSignal(tuple)

    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi('third.ui', self)
        self.setFixedSize(561, 481)

        self.Back2_Button.clicked.connect(self.go_back)
        self.Button_Sign_In.clicked.connect(self.on_Button_Sign_In_clicked)

        # Создание экземпляра AdminWindow заранее
        self.admin_window = AdminWindow(self)

        # Подключение к базе данных
        self.db_connection = sqlite3.connect('chemists.db')
        self.cursor = self.db_connection.cursor()

    def go_back(self):
        # Скрыть текущий диалог вместо его отклонения
        self.hide()

    def on_Button_Sign_In_clicked(self):
        # Получить логин и пароль из полей ввода
        login = self.lineEdit2_login.text()
        password = self.lineEdit2_password.text()

        try:
            # Подключение к базе данных
            db_connection = sqlite3.connect('chemists.db')
            cursor = db_connection.cursor()

            if login == 'admin' and password == 'admin':
                # Успешный вход для администратора, открыть окно администратора
                self.open_admin_window()
            else:
                # Проверка, существуют ли логин и пароль в таблице "Клиенты"
                cursor.execute('SELECT * FROM Клиенты WHERE логин = ? AND пароль = ?', (login, password))
                client_data = cursor.fetchone()

                if client_data:
                    # Успешный вход пользователя, отправить сигнал и открыть диалог пользователя
                    self.user_logged_in.emit((login, password))
                    self.open_user_dialog()
                else:
                    # Несовпадение учетных данных, отобразить сообщение
                    QMessageBox.warning(self, 'Предупреждение', 'Неверный логин или пароль.')

        except sqlite3.Error as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось проверить данные: {str(e)}')
        except Exception as ex:
            QMessageBox.warning(self, 'Ошибка', f'Произошла ошибка: {str(ex)}')
        finally:
            # Закрыть соединение с базой данных в блоке finally
            self.db_connection.close()

    def open_admin_window(self):
        # Открыть окно администратора
        self.admin_window.show()
        self.hide()

    def open_user_dialog(self):
        # Создать и показать диалог пользователя, передав курсор и соединение с базой данных
        user_dialog = user(self, third_dialog=self, cursor=self.cursor, db_connection=self.db_connection)
        user_dialog.user_logged_in.connect(self.on_user_logged_in)  # Подключить сигнал в третьем классе
        user_dialog.exec_()

    def on_user_logged_in(self, client_data):
        print("User logged in (from third):", client_data)